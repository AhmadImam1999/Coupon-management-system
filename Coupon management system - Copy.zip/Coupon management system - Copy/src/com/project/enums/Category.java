package com.project.enums;


	
	public enum Category {
		
		Food(1,"food") ,
		Electricity(2,"electricity"),
		Restaurant(3,"resturant"),
		Vacation(4 ,"vacation");
		
	
		
	private int id;
	private String name;
	
	
	
	private Category() {
		
		}
		
		private Category(int id, String name) {
			this.id = id;
			this.name = name;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
	
		
	}
	




