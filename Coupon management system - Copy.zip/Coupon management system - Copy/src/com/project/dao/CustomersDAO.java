package com.project.dao;

import java.sql.SQLException;
import java.util.List;

import com.project.beans.Company;
import com.project.beans.Coupon;
import com.project.beans.Customer;
import com.project.enums.Category;

import exceptions.ProjectException;

public interface CustomersDAO {

	boolean isCustomerExists(String email, String password) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException;
	void updateCustomer(Customer customer) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException;;
	void deleteCustomer(int customerID) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException;
	List <Customer> getAllCustomers() throws ProjectException, ClassNotFoundException, SQLException, InterruptedException;
	Customer getOneCustomer(int customerID) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException;;
	List <Coupon> getAllCustomer(int customerId) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException;
	int addCustomer(Customer customer) throws ProjectException, ClassNotFoundException, InterruptedException, SQLException;
	boolean isPurchaseExist(int customerId, int id);
	List<Coupon> getAllCustomerCoupons(int customerId, Category category);
	List<Coupon> getAllCustomerCoupons(int customerId, int maxPrice);
}
