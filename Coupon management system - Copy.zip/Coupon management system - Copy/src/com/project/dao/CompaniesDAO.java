package com.project.dao;

import java.sql.SQLException;
import java.util.List;

import com.project.beans.Company;
import com.project.beans.Coupon;
import com.project.enums.Category;

import exceptions.ProjectException;

public interface CompaniesDAO {
	

	
	boolean isCompanyExists(String email, String password) throws ProjectException, ClassNotFoundException, InterruptedException, SQLException;	
	int addCompany(Company company) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException;
	void updateCompany(Company company) throws ProjectException, ClassNotFoundException, SQLException;
	void deleteCompany(int companyID) throws ProjectException, ClassNotFoundException, SQLException;
	List <Company> getAllCompanies() throws ProjectException, ClassNotFoundException, SQLException;
	Company getOneCompany(int companyID) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException;
	Company getCompanyByEmailAndPassword(String email, String passwaord) throws ProjectException, ClassNotFoundException, SQLException;
	List<Coupon> getCompanyCoupons(int companyId, Category category) throws ProjectException, ClassNotFoundException, InterruptedException, SQLException;
	List<Coupon> getCompanyCoupons(int companyId, double maxPrice) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException;
	List<Coupon> getCompanyCoupons(int companyId) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException;
}
