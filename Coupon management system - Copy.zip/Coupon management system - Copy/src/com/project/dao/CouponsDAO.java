package com.project.dao;

	import java.sql.SQLException;
import java.util.List;

	import com.project.beans.Coupon;
	import com.project.enums.Category;

import exceptions.ProjectException;

	public interface CouponsDAO {
		
		
		int addCoupon(Coupon coupon) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException;
		void updateCoupon(Coupon coupon) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException;
		void deleteCoupon(int couponID) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException;
		List <Coupon> getAllCoupons() throws ProjectException, ClassNotFoundException, SQLException, InterruptedException;
		Coupon getOneCoupon(int couponID) throws ProjectException, ClassNotFoundException, InterruptedException, SQLException;
		void addCouponPurchase(int customerID, int couponID) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException;
		void deletCouponPurchase(int customerID, int couponID) throws ProjectException, ClassNotFoundException, InterruptedException, SQLException;
		void deleteExpiredCoupons()throws ProjectException, ClassNotFoundException, InterruptedException, SQLException;

}
