   
package com.project.facades;

import java.sql.SQLException;
import java.util.List;

import com.project.beans.Company;
import com.project.beans.Customer;
import com.project.dao.CompaniesDAO;
import com.project.dao.CouponsDAO;
import com.project.dao.CustomersDAO;


import exceptions.ProjectException;


public class AdministratorFacade extends mainFacade {

	private String Adminemail = "admin@admin.com";
	private String Adminpassword = "admin";

	public AdministratorFacade(CompaniesDAO companiesDao, CustomersDAO customersDao, CouponsDAO couponsDao) {
		super(companiesDao, customersDao, couponsDao);
		
	}

	public boolean login(String email, String password) {
		
		return email.equals(Adminemail) && password.equals(Adminpassword);
	}

	
	public int addCompany(Company company) throws ProjectException, ClassNotFoundException, InterruptedException, SQLException {
		if (this.companiesDao.isCompanyExists(company.getEmail() ,  company.getPassword())) {
			throw new ProjectException("addCompany failed the name " + company.getName() + " already exists");
		}
		
		return this.companiesDao.addCompany(company);
	}

	public void updateCompany(Company company) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException {
		Company companyFromDB = companiesDao.getOneCompany(company.getCompanyID());
		companyFromDB.setEmail(company.getEmail());
		companyFromDB.setPassword(company.getPassword());
		companiesDao.updateCompany(companyFromDB);
	}

	public void deleteCompany(int companyID) throws ProjectException, ClassNotFoundException, SQLException {
		
		companiesDao.deleteCompany(companyID);
	}

	public List<Company> getAllCompanies() throws ProjectException, ClassNotFoundException, SQLException {
		return companiesDao.getAllCompanies();

	}

	public Company getOneCompany(int companyID) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException {
		return companiesDao.getOneCompany(companyID);
	}

	public int addCustomer(Customer customer) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException {
		if (this.customersDao.isCustomerExists(customer.getEmail(), customer.getPassword())) {
			throw new ProjectException("addCustomer failed the email " + customer.getEmail() + " already exists");
		}
		return this.customersDao.addCustomer(customer);
	}

	public void updateCustomer(Customer customer) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException {
		customersDao.updateCustomer(customer);

	}

	public void deleteCustomer(int CustomerID) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException {
		customersDao.deleteCustomer(CustomerID);
	}

	public List<Customer> getAllCustomers() throws ProjectException, ClassNotFoundException, SQLException, InterruptedException {
		return customersDao.getAllCustomers();

	}

	public Customer getOneCustomer(int CustomerID) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException {
		return customersDao.getOneCustomer(CustomerID);

	}

}
