package com.project.facades;


import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import com.project.beans.Coupon;
import com.project.beans.Customer;
import com.project.dao.CompaniesDAO;
import com.project.dao.CouponsDAO;
import com.project.dao.CustomersDAO;
import com.project.enums.Category;

import exceptions.ProjectException;


public class CustomerFacade extends mainFacade {

	private int customerId;
	
	public CustomerFacade(CompaniesDAO companiesDao, CustomersDAO customersDao, CouponsDAO couponsDao) {
		super(companiesDao, customersDao, couponsDao);
	}

	public boolean login(String email, String passwaord) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException {
		if(customersDao.isCustomerExists(email, passwaord)) {
			
			this.customerId = customersDao.getOneCustomer(customerId).getId();
			return true;
		}
	
	return false;	
			
}

	public void PurchaseCoupon(Coupon coupon) throws ProjectException {
		// check if this customer don't have this coupon;
		try {
			 coupon = couponsDao.getOneCoupon(coupon.getId());
//			couponsDao.addCouponPurchase(this.customerId, CouponId);
			if(customersDao.isPurchaseExist(customerId, coupon.getId())) {
				throw new ProjectException("PurchaseCoupon failed - customer already have  this coupon");
			}
//			couponsDao.addCoupon(coupon);
			if (coupon.getAmount() == 0) {
				throw new ProjectException("PurchaseCoupon failed - amount is 0");
			}
			if (coupon.getEnd_date().before(new Date())) {
				throw new ProjectException("coupon is expired");
			}
			couponsDao.addCouponPurchase(this.customerId, coupon.getId());
			coupon.setAmount(coupon.getAmount() - 1);
			couponsDao.updateCoupon(coupon);
		} catch (Exception e) {
			throw new ProjectException("PurchaseCoupon failed", e);
		}

	}

	public List<Coupon> getAllCustomerCoupons() throws ProjectException, ClassNotFoundException, SQLException, InterruptedException {
		return customersDao.getAllCustomer(customerId);	

	}

	public List<Coupon> getCustomerCoupons(Category category) throws ProjectException {
		return customersDao.getAllCustomerCoupons(customerId, category);
		
	}
	public List<Coupon> getCustomerCoupons(int customerId ,int maxPrice) throws ProjectException {
		return customersDao.getAllCustomerCoupons(customerId, maxPrice);

		}
	
	public Customer getAllCustomerDetails() throws ProjectException, ClassNotFoundException, SQLException, InterruptedException {
		return customersDao.getOneCustomer(customerId);

	}

}
