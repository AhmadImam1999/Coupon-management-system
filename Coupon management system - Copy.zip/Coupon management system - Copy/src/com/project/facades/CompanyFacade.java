package com.project.facades;

import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import com.project.beans.Company;
import com.project.beans.Coupon;
import com.project.beans.Customer;
import com.project.dao.CompaniesDAO;
import com.project.dao.CouponsDAO;
import com.project.dao.CustomersDAO;
import com.project.enums.Category;

import exceptions.ProjectException;


public class CompanyFacade extends mainFacade {
	private int companyId;
	
	
	public CompanyFacade(CompaniesDAO companiesDao, CustomersDAO customersDao, CouponsDAO couponsDao) {
		super(companiesDao, customersDao, couponsDao);
	}

	public boolean login(String email, String passwaord) throws ClassNotFoundException, SQLException, InterruptedException, ProjectException {
		try {
			Company company = null;
			company = companiesDao.getCompanyByEmailAndPassword(email, passwaord);
			this.companyId = company.getCompanyID();
			return true;
		} catch (ProjectException e) {
			return false;
		}
		
		
		
	
	}

	public int addCoupon(Coupon coupon) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException {
		
	
		if (coupon.getEnd_date().before(new Date(System.currentTimeMillis()))) {
			throw new ProjectException("addCoupon failed this coupon already expired");
		}
		if (coupon.getEnd_date().before(coupon.getStart_date())) {
			throw new ProjectException("addCoupon failed the end date is before start date");

		}
		return this.couponsDao.addCoupon(coupon);
	}

	public void UpdateCoupon(Coupon coupon) throws ProjectException, ClassNotFoundException, InterruptedException, SQLException {
		Coupon couponFromDb = this.couponsDao.getOneCoupon(coupon.getId());
		if (couponFromDb.getCompanyID() != this.companyId) {
			throw new ProjectException("UpdateCoupon failed - this coupon does not belong to this company");
		}
		couponFromDb.setAmount(coupon.getAmount());
		couponFromDb.setCategory(coupon.getCategory());
		couponFromDb.setDescription(coupon.getDescription());
		couponFromDb.setStart_date(coupon.getStart_date());
		couponFromDb.setEnd_date(coupon.getEnd_date());
		couponFromDb.setImage(coupon.getImage());
		couponFromDb.setPrice(coupon.getPrice());
		couponFromDb.setTitle(coupon.getTitle());
		couponsDao.updateCoupon(couponFromDb);
	}

	public void deleteCoupon(int couponId) throws ProjectException, ClassNotFoundException, InterruptedException, SQLException {
		Coupon couponToDelete = this.couponsDao.getOneCoupon(couponId);
		if (couponToDelete.getCompanyID() == this.companyId) {
			this.couponsDao.deleteCoupon(couponId);
		} else {
			throw new ProjectException("deleteCoupon failed - not found in this company");
		}
	}
	public List<Coupon> getCompanyCoupons(int companyId, Category category) throws ProjectException, ClassNotFoundException, InterruptedException, SQLException {
		return companiesDao.getCompanyCoupons(companyId, category);

	}

	public List<Coupon> getCompanyCoupons(int companyId, double maxPrice) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException {
		return companiesDao.getCompanyCoupons(companyId, maxPrice);

	}
	
	public List<Coupon> getCompanyCoupons(int companyId) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException {
		return companiesDao.getCompanyCoupons(companyId);

	}

	public Company getCompanyDetails() throws ProjectException, ClassNotFoundException, SQLException, InterruptedException {
		return companiesDao.getOneCompany(companyId);

	}

}
