package com.project.facades;

import java.sql.SQLException;

import com.project.dao.CompaniesDAO;
import com.project.dao.CouponsDAO;
import com.project.dao.CustomersDAO;

import exceptions.ProjectException;

public abstract class mainFacade {

	protected CompaniesDAO companiesDao;
	protected CustomersDAO customersDao;
	protected CouponsDAO couponsDao;


	public mainFacade(CompaniesDAO companiesDao, CustomersDAO customersDao, CouponsDAO couponsDao) {
		this.companiesDao = companiesDao;
		this.customersDao = customersDao;
		this.couponsDao = couponsDao;
	}
//	@Override
	public abstract boolean login(String email, String passwaord) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException;
	
	
}
