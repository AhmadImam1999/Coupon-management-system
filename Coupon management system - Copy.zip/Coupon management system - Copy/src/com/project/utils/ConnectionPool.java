package com.project.utils;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import exceptions.ProjectException;

public class ConnectionPool {

	private static ConnectionPool instance; 
	private static Set<Connection> connections = new HashSet<>();
	public static final int max_Connenctions = 10;
	private static String DATABASE_URL = "jdbc:mysql://127.0.0.1:3306/couponproject";
	private static String DATABASE_USERNAME = "root";
	private static String DATABASE_PASSWORD = "123987ahmad";
	private static String DRIVER_NAME = "com.mysql.jdbc.Driver";

	private ConnectionPool() throws ClassNotFoundException, SQLException,ProjectException { 

		Class.forName( DRIVER_NAME);
		for (int i = 0; i < max_Connenctions; i++) {
			connections.add(DriverManager.getConnection(DATABASE_URL,DATABASE_USERNAME,DATABASE_PASSWORD));
		}
	}

	public static ConnectionPool getInstance() throws ProjectException, ClassNotFoundException, SQLException { 
		if (instance == null) {
			instance = new ConnectionPool();
		}
		return instance;
	}

	

	public synchronized Connection getConnection()throws InterruptedException,ProjectException {
		try {
			while(connections.isEmpty()) {
				wait();
			}
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
		Iterator<Connection> it = connections.iterator();
		Connection con = it.next();
		it.remove();
		return con;
	}
	
	public synchronized void restoreConnection(Connection con)throws ProjectException {
		connections.add(con);
		
		
		
		
		notify();
	}
	
	public void closeAllConnections() throws ProjectException {
		Iterator<Connection> it = connections.iterator();
		while(it.next() != null)
		{
			try {
				it.next().close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
	}

}