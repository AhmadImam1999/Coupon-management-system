package com.project.dbDao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.project.beans.Coupon;
import com.project.dao.CouponsDAO;
import com.project.enums.Category;
import com.project.utils.ConnectionPool;

import exceptions.ProjectException;

public class CouponsDBDAO implements CouponsDAO {

	@Override
	public int addCoupon(Coupon coupon) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException {
		Connection connection = null;
		try {
			connection = ConnectionPool.getInstance().getConnection();
			String sqlStatement = "insert into coupons (company_id, category_id, title, description, start_date, end_date, amount, price, image) values(?,?,?,?,?,?,?,?,?)";
			PreparedStatement statement = connection.prepareStatement(sqlStatement,
					PreparedStatement.RETURN_GENERATED_KEYS);
			statement.setInt(1, coupon.getCompanyID());
			statement.setInt(2, coupon.getCategory().ordinal() + 1);
			statement.setString(3, coupon.getTitle());
			statement.setString(4, coupon.getDescription());
			statement.setDate(5, coupon.getStart_date());
			statement.setDate(6, coupon.getEnd_date());
			statement.setInt(7, coupon.getAmount());
			statement.setDouble(8, coupon.getPrice());
			statement.setString(9, coupon.getImage());

			statement.executeUpdate();

			ResultSet rsKeys = statement.getGeneratedKeys();
			rsKeys.next();
			return rsKeys.getInt(1);
		} catch (SQLException e) {
			throw new ProjectException("addCoupon faild", e);
		} finally {
			if (connection != null) {
				ConnectionPool.getInstance().restoreConnection(connection);
			}
		}

	}

	@Override
	public void updateCoupon(Coupon coupon) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException {
		Connection connection = null;
		try {
			connection = ConnectionPool.getInstance().getConnection();
			String sqlStatement = "update coupons set company_id=?, category_id=?, title=?, description=?, start_date=?, end_date=?, amount=?, price=?, image=? where id=?";
			PreparedStatement statement = connection.prepareStatement(sqlStatement);
			statement.setInt(1, coupon.getCompanyID()); 
			statement.setInt(2, coupon.getCategory().ordinal());
			statement.setString(3, coupon.getTitle());
			statement.setString(4, coupon.getDescription());
			statement.setDate(5, coupon.getStart_date());
			statement.setDate(6, coupon.getEnd_date());
			statement.setInt(7, coupon.getAmount());
			statement.setDouble(8, coupon.getPrice());
			statement.setString(9, coupon.getImage());
			statement.setInt(10, coupon.getId()); 
			statement.executeUpdate();
		} catch (SQLException e) {
			throw new ProjectException("updateCoupon faild", e);
		} finally {
			if (connection != null) {
				ConnectionPool.getInstance().restoreConnection(connection);
			}
		}

	}

	@Override
	public void deleteCoupon(int couponID) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException {
		Connection connection = null;
		try {
			connection = ConnectionPool.getInstance().getConnection();
			String sqlStatement = "Delete from coupons where id=?";
			PreparedStatement statement = connection.prepareStatement(sqlStatement);
			statement.setInt(1, couponID);
			statement.executeUpdate();

		} catch (SQLException e) {
			throw new ProjectException("deleteCoupon faild", e);
		} finally {
			if (connection != null) {
				ConnectionPool.getInstance().restoreConnection(connection);
			}
		}

	}

	@Override
	public List<Coupon> getAllCoupons() throws ProjectException, ClassNotFoundException, SQLException, InterruptedException {
		List<Coupon> list = new ArrayList<>();
		Connection con = null;
		try {
			con = ConnectionPool.getInstance().getConnection();
			String sql = "select * from coupons";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				Coupon coupon = new Coupon();
				coupon.setId(rs.getInt("id"));
				coupon.setPrice(rs.getDouble("Price"));
				coupon.setAmount(rs.getInt("Amount"));
				coupon.setCompanyID(rs.getInt("Company_id"));
				coupon.setCategory((com.project.enums.Category.values()[rs.getInt("Category_id")]));
				coupon.setTitle(rs.getString("Title"));
				coupon.setDescription(rs.getString("Description"));
				coupon.setImage(rs.getString("Image"));
				coupon.setStart_date(rs.getDate("Start_date"));
				coupon.setEnd_date(rs.getDate("End_date"));
				list.add(coupon);
			}
			return list;
		} catch (SQLException e) {
			throw new ProjectException("getAllCompanies failed", e);
		} finally {
			ConnectionPool.getInstance().restoreConnection(con);
		}
	}

	@Override
	public Coupon getOneCoupon(int couponID) throws ProjectException, ClassNotFoundException, InterruptedException, SQLException {
		Coupon coupon = null;
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet result = null;
		try {
			connection = ConnectionPool.getInstance().getConnection();
			String sqlStatement = "select * from coupons where id=?";
			statement = connection.prepareStatement(sqlStatement);
			statement.setInt(1, couponID);
			result = statement.executeQuery();
			if (result.next()) {
				coupon = new Coupon();
				coupon.setId(result.getInt("id"));
				coupon.setCompanyID(result.getInt("company_id"));
				coupon.setPrice(result.getDouble("price"));
				Category[] categories = Category.values();
				int index = result.getInt("category_id") - 1;
				coupon.setCategory(categories[index]);
				coupon.setTitle(result.getString("title"));
				coupon.setDescription(result.getString("description"));
				coupon.setImage(result.getString("image"));
				coupon.setAmount(result.getInt("amount"));
				coupon.setStart_date(result.getDate("start_date"));
				coupon.setEnd_date(result.getDate("end_date"));

				return coupon;
			} else {
				throw new ProjectException("getOneCoupon faild - not found");
			}
		} catch (SQLException e) {
			throw new ProjectException("getOneCoupon faild", e);
		} finally {
			if (connection != null) {
				ConnectionPool.getInstance().restoreConnection(connection);
			}
		}
	}

	@Override
	public void addCouponPurchase(int customerID, int couponID) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException {
		Connection connection = null;
		try {
			connection = ConnectionPool.getInstance().getConnection();
			String sqlStatement = "insert into customers_coupons values(?, ?)";
			PreparedStatement statement = connection.prepareStatement(sqlStatement);
			statement.setInt(1, customerID);
			statement.setInt(2, couponID);
			statement.executeUpdate();
		} catch (SQLException e) {
			throw new ProjectException("getOneCoupon faild", e);
		} finally {
			if (connection != null) {
				ConnectionPool.getInstance().restoreConnection(connection);
			}
		}
		

	}

	@Override
	public void deletCouponPurchase(int customerID, int couponID) throws ProjectException, ClassNotFoundException, InterruptedException, SQLException {
		Connection connection = null;
		try {
			connection = ConnectionPool.getInstance().getConnection();
			String sqlStatement = "Delete from customers_coupons where coupon_id=? and customers_id=?";
			PreparedStatement statement = connection.prepareStatement(sqlStatement);
			statement.setInt(1, customerID);
			statement.setInt(2, couponID);
			statement.executeUpdate();
		} catch (SQLException e) {
			throw new ProjectException("getOneCoupon faild", e);
		} finally {
			if (connection != null) {
				ConnectionPool.getInstance().restoreConnection(connection);
			}
		}
	}
	
	@Override
	public void deleteExpiredCoupons() throws ProjectException, ClassNotFoundException, SQLException, InterruptedException {
		Connection connection = null;
		try {
			connection = ConnectionPool.getInstance().getConnection();
			// 1. delete all purchases of the expired coupons
			String sqlStatement = "delete from customers_coupons where coupon_id in (select id from coupons where end_date < ? )";		
			PreparedStatement statement = connection.prepareStatement(sqlStatement);
			statement.setDate(1, new Date(System.currentTimeMillis()));
			statement.executeUpdate();
			// 2. delete all expired coupons
			sqlStatement = "delete from coupons where end_date < ? ";		
			statement = connection.prepareStatement(sqlStatement);
			statement.setDate(1, new Date(System.currentTimeMillis()));
			statement.executeUpdate();
		} catch (SQLException e) {
			throw new ProjectException("deleteExpiredCoupons failed", e);
		} finally {
			if (connection != null) {
				ConnectionPool.getInstance().restoreConnection(connection);
			}
		}
		
	}

}
