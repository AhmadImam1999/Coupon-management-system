package com.project.dbDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.project.beans.Coupon;
import com.project.beans.Customer;
import com.project.dao.CustomersDAO;
import com.project.enums.Category;
import com.project.utils.ConnectionPool;
import exceptions.ProjectException;


public class CustomersDBDAO implements CustomersDAO {

	@Override
	public boolean isCustomerExists(String email, String password) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException {
		Connection connection = null;
		try {
			connection = ConnectionPool.getInstance().getConnection();
			String sqlStatement = "select * from customers where email=? and password=?";
			PreparedStatement statement = connection.prepareStatement(sqlStatement);
			statement.setString(1, email);
			statement.setString(2, password);
			ResultSet rs = statement.executeQuery();
			return rs.next(); // will return true if the customer found
		} catch (SQLException e) {
			throw new ProjectException("isCustomerExists failed", e);
		} finally {
			if (connection != null) {
				ConnectionPool.getInstance().restoreConnection(connection);
			}
		}

	}

	@Override
	public void updateCustomer(Customer customer) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException {
		Connection connection = null;
		try {
			connection = ConnectionPool.getInstance().getConnection();
			String sqlStatement = "update customers set first_name=?, last_name=?, email=?, password=? where id=?";
			PreparedStatement statement = connection.prepareStatement(sqlStatement);
			statement.setString(1, customer.getFirst_name());
			statement.setString(2, customer.getLast_name());
			statement.setString(3, customer.getEmail());
			statement.setString(4, customer.getPassword());
			statement.setInt(5, customer.getId());
			statement.executeUpdate();
		} catch (SQLException e) {
			throw new ProjectException("updateCustomer failed", e);
		} finally {
			if (connection != null) {
				ConnectionPool.getInstance().restoreConnection(connection);
			}
		}
	}

	@Override
	public void deleteCustomer(int customerID) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException {
		Connection connection = null;
		try {
			connection = ConnectionPool.getInstance().getConnection();
			String sqlStatement = "Delete from customers where id=?";
			PreparedStatement statement = connection.prepareStatement(sqlStatement);
			statement.setInt(1, customerID);
			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				ConnectionPool.getInstance().restoreConnection(connection);
			}
		}

	}

	@Override
	public List<Customer> getAllCustomers() throws ProjectException, ClassNotFoundException, SQLException, InterruptedException {
		List<Customer> list = new ArrayList<>();
		Connection con = null;
		try {
			con = ConnectionPool.getInstance().getConnection();
			String sql = "select * from customers";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				Customer customer = new Customer();
				customer.setId(rs.getInt("id"));
				customer.setFirst_name(rs.getString("first_name"));
				customer.setLast_name(rs.getString("last_name"));
				customer.setEmail(rs.getString("email"));
				customer.setPassword(rs.getString("password"));
				list.add(customer);
				System.out.println(customer);
			}
			return list;
		} catch (SQLException e) {
			throw new ProjectException("getAllCompanies failed", e);
		} finally {
			ConnectionPool.getInstance().restoreConnection(con);
		}
		
	}

	@Override
	public Customer getOneCustomer(int customerID) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException {
		Customer customer = null;
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet result = null;
		try {
			connection = ConnectionPool.getInstance().getConnection();
			String sqlStatement = "select * from customers where id=?";
			statement = connection.prepareStatement(sqlStatement);
			statement.setInt(1, customerID);
			result = statement.executeQuery();
			if (result.next()) {
				customer = new Customer();
				customer.setId(result.getInt("id"));
				customer.setFirst_name(result.getString("First_name"));
				customer.setLast_name(result.getString("Last_name"));
				customer.setEmail(result.getString("Email"));
				customer.setPassword(result.getString("Password"));
				System.out.println(customer.toString());
			} else {
				System.out.println("cannot find any customers");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				ConnectionPool.getInstance().restoreConnection(connection);
			}
		}
		return customer;
	}

	@Override
	public List<Coupon> getAllCustomer(int customerId) throws ProjectException, ClassNotFoundException, SQLException, InterruptedException {
		List<Coupon> list = new ArrayList<>();
		Connection con = null;
		try {
			con = ConnectionPool.getInstance().getConnection();
			String sql = "select * from coupons where id in(select coupon_id from customers_coupons where customer_id=?)";
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setInt(1, customerId);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				Coupon coupon = new Coupon();
				coupon.setId(rs.getInt("id"));
				coupon.setPrice(rs.getDouble("Price"));
				coupon.setAmount(rs.getInt("Amount"));
				coupon.setCompanyID(rs.getInt("Company_id"));
				coupon.setCategory((com.project.enums.Category.values()[rs.getInt("Category_id")]));
				coupon.setTitle(rs.getString("Title"));
				coupon.setDescription(rs.getString("Description"));
				coupon.setImage(rs.getString("Image"));
				coupon.setStart_date(rs.getDate("Start_date"));
				coupon.setEnd_date(rs.getDate("End_date"));
				list.add(coupon);
			}
			return list;
		} catch (SQLException e) {
			throw new ProjectException("getAllCustomerCoupons failed", e);
		} finally {
			ConnectionPool.getInstance().restoreConnection(con);
		}
	}
	
	
	@Override
	public int addCustomer(Customer customer) throws ProjectException, ClassNotFoundException, InterruptedException, SQLException {
		Connection connection = null;
		try {
			connection = ConnectionPool.getInstance().getConnection();
			String sqlStatement = "insert into customers (first_name, last_name, email, password) values(?,?,?,?)";
			PreparedStatement statement = connection.prepareStatement(sqlStatement,
					PreparedStatement.RETURN_GENERATED_KEYS);
//			statement.setInt(1, newCustomer.getId());
			statement.setString(1, customer.getFirst_name());
			statement.setString(2, customer.getLast_name());
			statement.setString(3, customer.getEmail());
			statement.setString(4, customer.getPassword());
//			statement.setObject(5, customer.getCoupons());

			statement.executeUpdate();

			ResultSet rsId = statement.getGeneratedKeys();
			rsId.next();
			int theId = rsId.getInt(1);
			return theId;

		} catch (SQLException e) {
			throw new ProjectException("addCustomer fail", e);
		} finally {
			if (connection != null) {
				ConnectionPool.getInstance().restoreConnection(connection);
			}
		}

	}

	@Override
	public boolean isPurchaseExist(int customerId, int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Coupon> getAllCustomerCoupons(int customerId, Category category) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Coupon> getAllCustomerCoupons(int customerId, int maxPrice) {
		// TODO Auto-generated method stub
		return null;
	}


}
